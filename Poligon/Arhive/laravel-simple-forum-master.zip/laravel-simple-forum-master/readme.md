- composer install / update
- change your config database 
- php artisan migrate
- php artisan key:generate
- Add your recaptcha key on .env

- php artisan migrate --seed

- email = admin@email.com
  password = password

- add your forum and categories on Admin/dashboard on your url


## Screenshot
![Halaman Home](https://github.com/mahmudinm/laravel-simple-forum/raw/master/ScreenShot/home.png)

![Halaman Thread](https://github.com/mahmudinm/laravel-simple-forum/raw/master/ScreenShot/thread.png)

![Halaman Profil](https://github.com/mahmudinm/laravel-simple-forum/raw/master/ScreenShot/profil.png)

![Halaman Create](https://github.com/mahmudinm/laravel-simple-forum/raw/master/ScreenShot/create.png)

![Halaman Admin Category](https://github.com/mahmudinm/laravel-simple-forum/raw/master/ScreenShot/admin_category.png)
