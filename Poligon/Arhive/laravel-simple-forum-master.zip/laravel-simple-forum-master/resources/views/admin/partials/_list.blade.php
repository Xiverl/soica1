<div class="col-md-2">
  <div class="list-group">
    <a href="#" class="list-group-item active">Menu</a>
    <a href="{{ route('admin.dashboard') }}" class="list-group-item">Dashboard</a>
    <a href="{{ route('admin.forums.index') }}" class="list-group-item">Forum</a>
    <a href="{{ route('admin.categories.index') }}" class="list-group-item">Category</a>
  </div>
</div>