@extends('layouts.app')

@section('style')
  <link rel="stylesheet" href="/css/jasny-bootstrap.css">
@stop

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
          <h1>404 . Page not found </h1>
        </div>
    </div>
</div>
@endsection



@section('script')
  <script src="/js/jasny-bootstrap.js"></script>
@stop
